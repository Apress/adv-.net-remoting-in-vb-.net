Create a "virtual root" in IIS Admin called "MyServer" pointing to this directory's vroot subdirectory to test the example.

When recompiling, you have to place the server.dll in vroot\bin!


