Option Explicit On 
Option Strict On

Imports System
Imports System.Collections

Public Class POP3Msg
    Public MsgFrom As String
    Public MsgTo As String
    Public Body As String
    Public Headers As String
    Public MessageId As String
    Public InReplyTo As String
End Class
