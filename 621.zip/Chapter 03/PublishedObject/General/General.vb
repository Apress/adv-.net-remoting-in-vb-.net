Imports System

Public Interface IMyRemoteObject
    Sub setValue(ByVal newval As Integer)
    Function getValue() As Integer
End Interface

